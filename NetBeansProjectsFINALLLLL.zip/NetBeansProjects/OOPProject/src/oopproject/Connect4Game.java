/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package oopproject;

import java.awt.Color;

/**
 *
 * @author HP
 */
public class Connect4Game extends javax.swing.JFrame {
    public int turn=1,g1status=1,g2status=1,g3status=1;
public int g4status=1,g5status=1; 
      public int r1status=1,r2status=1,r3status=1,r4status=1,r5status=1,r6status=1;
      public int d1status=1,d2status=1,d3status=1,d4status=1,d5status=1,d6status=1,d7status=1,d8status=1;
      
      
public void switchturn(){
    if(turn==1){ turn=2; jLabel2.setText("Player 2 Turn");}
    else { turn=1; jLabel2.setText("Player 1 Turn");}
}
public int groupstatus(int group){
    if(group==1) return g1status;
    else if(group==2) return g2status;
    else if(group==3) return g3status;
    else if(group==4) return g4status;
    else if(group==5) return g5status;
    else return 0;   
}

public int rowstatus(int row){
    if(row==1) return r1status;
     else if(row==2) return r2status;
    else if(row==3) return r3status;
    else if(row==4) return r4status;
    else if(row==5) return r5status;
    else if(row==6) return r6status;
    else return 0;
    
}
public int diagonalstatus(int diagonal){
    if(diagonal==1) return d1status;
     else if(diagonal==2) return d2status;
    else if(diagonal==3) return d3status;
    else if(diagonal==4) return d4status;
    else if(diagonal==5) return d5status;
    else if(diagonal==6) return d6status;
    else if(diagonal==7) return d7status;
    else if(diagonal==8) return d8status;
    else return 0;
    
}


private void disableAllButtons() {
    jButton1.setEnabled(false);
    jButton2.setEnabled(false);
    jButton3.setEnabled(false);
    jButton4.setEnabled(false);
    jButton5.setEnabled(false);
    jButton6.setEnabled(false);
    jButton8.setEnabled(false);
    jButton9.setEnabled(false);
    jButton10.setEnabled(false);
    jButton11.setEnabled(false);
    jButton12.setEnabled(false);
    jButton13.setEnabled(false);
    jButton15.setEnabled(false);
    jButton16.setEnabled(false);
    jButton17.setEnabled(false);
    jButton18.setEnabled(false);
    jButton19.setEnabled(false);
    jButton20.setEnabled(false);
    jButton22.setEnabled(false);
    jButton23.setEnabled(false);
    jButton24.setEnabled(false);
    jButton25.setEnabled(false);
    jButton26.setEnabled(false);
    jButton27.setEnabled(false);
    jButton29.setEnabled(false);
    jButton30.setEnabled(false);
    jButton31.setEnabled(false);
    jButton32.setEnabled(false);
    jButton33.setEnabled(false);
    jButton34.setEnabled(false);
    // Disable other buttons similarly
}
 public void checkWinRow(){
    String a=jButton1.getBackground().toString();
    String b=jButton2.getBackground().toString();
    String c=jButton3.getBackground().toString();
    String d=jButton4.getBackground().toString();
    String e=jButton5.getBackground().toString();
    String f=jButton6.getBackground().toString();
    //group 2
    String g=jButton8.getBackground().toString();
    String h=jButton9.getBackground().toString();
    String i=jButton10.getBackground().toString();
    String j=jButton11.getBackground().toString();
    String k=jButton12.getBackground().toString();
    String l=jButton13.getBackground().toString();
    //group 3
    String m=jButton15.getBackground().toString();
    String n=jButton16.getBackground().toString();
    String o=jButton17.getBackground().toString();
    String p=jButton18.getBackground().toString();
    String q=jButton19.getBackground().toString();
    String r=jButton20.getBackground().toString();
    //group 4
    String s=jButton22.getBackground().toString();
    String t=jButton23.getBackground().toString();
    String u=jButton24.getBackground().toString();
    String v=jButton25.getBackground().toString();
    String w=jButton26.getBackground().toString();
    String x=jButton27.getBackground().toString();
    //group 5
    String y=jButton29.getBackground().toString();
    String z=jButton30.getBackground().toString();
    String a31=jButton31.getBackground().toString();
    String a32=jButton32.getBackground().toString();
    String a33=jButton33.getBackground().toString();
    String a34=jButton34.getBackground().toString();
    if(r1status>=4){
       if(a.equals(g)&&g.equals(m)&&m.equals(s)){
            jLabel2.setText("Player Won");
             disableAllButtons();
        } 
       else if(g.equals(m)&&m.equals(s)&&s.equals(y)){
            jLabel2.setText("Player Won");
             disableAllButtons();
       } 
    } 
       if(r2status>=4) {
           if(b.equals(h)&&h.equals(n)&&n.equals(t)){
            jLabel2.setText("Player Won");
             disableAllButtons();
        } 
       else if(h.equals(n)&&n.equals(t)&&t.equals(z)){
            jLabel2.setText("Player Won");
             disableAllButtons();
       } 
}
        if(r3status>=4){
            if(c.equals(i) && i.equals(o) && o.equals(u)){
            jLabel2.setText("Player Won");
             disableAllButtons();
        } 
       else if(i.equals(o)&& o.equals(u)&& u.equals(a31)){
            jLabel2.setText("Player Won");
             disableAllButtons();
       } 
    } 
         if(r4status>=4){
       if(d.equals(j)&& j.equals(p)&& p.equals(v)){
            jLabel2.setText("Player Won");
             disableAllButtons();
        } 
       else if(j.equals(p)&& p.equals(v)&& v.equals(a32)){
            jLabel2.setText("Player Won");
             disableAllButtons();
       } 
    } 
          if(r5status>=4){
       if(e.equals(k)&& k.equals(q)&& q.equals(w)){
            jLabel2.setText("Player Won");
             disableAllButtons();
        } 
       else if(k.equals(q)&& q.equals(w)&& w.equals(a33)){
            jLabel2.setText("Player Won");
             disableAllButtons();
       } 
    } 
           if(r6status>=4){
       if(f.equals(l)&& l.equals(r)&& r.equals(x)){
            jLabel2.setText("Player Won");
             disableAllButtons();
        } 
       else if(l.equals(r)&& r.equals(x)&& x.equals(a34)){
            jLabel2.setText("Player Won");
             disableAllButtons();
       } 
    } 




 }
public void checkWinDiagonal(){
    String a=jButton1.getBackground().toString();
    String b=jButton2.getBackground().toString();
    String c=jButton3.getBackground().toString();
    String d=jButton4.getBackground().toString();
    String e=jButton5.getBackground().toString();
    String f=jButton6.getBackground().toString();
    String g=jButton8.getBackground().toString();
    String h=jButton9.getBackground().toString();
    String i=jButton10.getBackground().toString();
    
    String j=jButton11.getBackground().toString();
    String k=jButton12.getBackground().toString();
    String l=jButton13.getBackground().toString();
    String m=jButton15.getBackground().toString();
    String n=jButton16.getBackground().toString();
    String o=jButton17.getBackground().toString();
    
    String p=jButton18.getBackground().toString();
    String q=jButton19.getBackground().toString();
    String r=jButton20.getBackground().toString();
    String s=jButton22.getBackground().toString();
    String t=jButton23.getBackground().toString();
    String u=jButton24.getBackground().toString();
    
    String v=jButton25.getBackground().toString();
    String w=jButton26.getBackground().toString();
    String x=jButton27.getBackground().toString();
    String y=jButton29.getBackground().toString();
    String z=jButton30.getBackground().toString();
    String a31=jButton31.getBackground().toString();
    String a32=jButton32.getBackground().toString();
    String a33=jButton33.getBackground().toString();
    String a34=jButton34.getBackground().toString();
     if (d1status >=4 ) {
    if(a.equals(h) && h.equals(o) && o.equals(v)){
        jLabel2.setText("Player Won");
        disableAllButtons();
    }
    else if(h.equals(o) && o.equals(v) && v.equals(a33)){
        jLabel2.setText("Player Won");
         disableAllButtons();
    }
}
     if(d2status>=4){
             if(b.equals(i) && i.equals(p) && p.equals(w)){
        jLabel2.setText("Player Won");
        disableAllButtons();
    }
    else if(i.equals(p) && p.equals(w) && w.equals(a34)){
        jLabel2.setText("Player Won");
         disableAllButtons();
    }
 }
      if(d3status>=4){
             if(c.equals(j) && j.equals(q) && q.equals(x)){
        jLabel2.setText("Player Won");
        disableAllButtons();
    }
   
 }
      if(d4status>=4){
             if(g.equals(n) && n.equals(u) && u.equals(a33)){
        jLabel2.setText("Player Won");
        disableAllButtons();
    }
   
 }
     if(d5status>=4){
             if(f.equals(k) && k.equals(p) && p.equals(u)){
        jLabel2.setText("Player Won");
        disableAllButtons();
    }
    else if(k.equals(p) && p.equals(u) && u.equals(z)){
        jLabel2.setText("Player Won");
         disableAllButtons();
    }
 }
     if(d6status>=4){
             if(e.equals(j) && j.equals(o) && o.equals(t)){
        jLabel2.setText("Player Won");
        disableAllButtons();
    }
    else if(j.equals(o) && o.equals(t) && t.equals(y)){
        jLabel2.setText("Player Won");
         disableAllButtons();
    }
 }
     if(d7status>=4){
             if(d.equals(i) && i.equals(n) && n.equals(s)){
        jLabel2.setText("Player Won");
        disableAllButtons();
    }
   
 }
     if(d8status>=4){
             if(l.equals(q) && q.equals(v) && v.equals(a31)){
        jLabel2.setText("Player Won");
        disableAllButtons();
    }
   
 }
}

 public void checkwin(){
    
    
    
    String a=jButton1.getBackground().toString();
    String b=jButton2.getBackground().toString();
    String c=jButton3.getBackground().toString();
    String d=jButton4.getBackground().toString();
    String e=jButton5.getBackground().toString();
    String f=jButton6.getBackground().toString();
    String g=jButton8.getBackground().toString();
    String h=jButton9.getBackground().toString();
    String i=jButton10.getBackground().toString();
    
    String j=jButton11.getBackground().toString();
    String k=jButton12.getBackground().toString();
    String l=jButton13.getBackground().toString();
    String m=jButton15.getBackground().toString();
    String n=jButton16.getBackground().toString();
    String o=jButton17.getBackground().toString();
    
    String p=jButton18.getBackground().toString();
    String q=jButton19.getBackground().toString();
    String r=jButton20.getBackground().toString();
    String s=jButton22.getBackground().toString();
    String t=jButton23.getBackground().toString();
    String u=jButton24.getBackground().toString();
    
    String v=jButton25.getBackground().toString();
    String w=jButton26.getBackground().toString();
    String x=jButton27.getBackground().toString();
    String y=jButton29.getBackground().toString();
    String z=jButton30.getBackground().toString();
    String a31=jButton31.getBackground().toString();
    String a32=jButton32.getBackground().toString();
    String a33=jButton33.getBackground().toString();
    String a34=jButton34.getBackground().toString();
     if (g1status >=4 ) {
    if(a.equals(b) && b.equals(c) && c.equals(d)){
        jLabel2.setText("Player Won");
        disableAllButtons();
    }
    else if(b.equals(c) && c.equals(d) && d.equals(e)){
        jLabel2.setText("Player Won");
         disableAllButtons();
    }
    else if(c.equals(d) && d.equals(e) && e.equals(f)){
        jLabel2.setText("Player Won");
         disableAllButtons();
    }}
      if(g2status>=4){
        if(g.equals(h)&&h.equals(i)&&i.equals(j)){
            jLabel2.setText("Player Won");
             disableAllButtons();
        }
        else if(h.equals(i) && i.equals(j) && j.equals(k)){
        jLabel2.setText("Player Won");
         disableAllButtons();
    }
        else if(i.equals(j) && j.equals(k) && k.equals(l)){
        jLabel2.setText("Player Won");
         disableAllButtons();
    }
     }
      if(g3status>=4){
         if(m.equals(n)&& n.equals(o) && o.equals(p)){
            jLabel2.setText("Player Won");
             disableAllButtons();
        }
          else if(n.equals(o) && o.equals(p) && p.equals(q)){
        jLabel2.setText("Player Won");
         disableAllButtons();
     }
          else if(o.equals(p) && p.equals(q) && q.equals(r)){
        jLabel2.setText("Player Won");
         disableAllButtons();
          }}
       if(g4status>=4){
          if(s.equals(t)&& t.equals(u) && u.equals(v)){
            jLabel2.setText("Player Won");
             disableAllButtons();
        }
          else if(t.equals(u) && u.equals(v) && v.equals(w)){
        jLabel2.setText("Player Won");
         disableAllButtons();
     }
          else if(u.equals(v) && v.equals(w) && w.equals(x)){
        jLabel2.setText("Player Won");
         disableAllButtons();
     }}
      if(g5status>=4){
         if(y.equals(z)&& z.equals(a31) && a31.equals(a32)){
            jLabel2.setText("Player Won");
             disableAllButtons();
        }
          else if(z.equals(a31) && a31.equals(a32) && a32.equals(a33)){
        jLabel2.setText("Player Won");
         disableAllButtons();
     }
          else if(a31.equals(a32) && a32.equals(a33) && a33.equals(a34)){
        jLabel2.setText("Player Won");
         disableAllButtons();
     } }
     
    }

    public Connect4Game() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jButton30 = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        jButton32 = new javax.swing.JButton();
        jButton33 = new javax.swing.JButton();
        jButton34 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Connect 4 Game");

        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });

        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });

        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });

        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton6MouseClicked(evt);
            }
        });
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton8MouseClicked(evt);
            }
        });

        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton9MouseClicked(evt);
            }
        });

        jButton10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton10MouseClicked(evt);
            }
        });

        jButton11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton11MouseClicked(evt);
            }
        });

        jButton12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton12MouseClicked(evt);
            }
        });

        jButton13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton13MouseClicked(evt);
            }
        });

        jButton15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton15MouseClicked(evt);
            }
        });

        jButton16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton16MouseClicked(evt);
            }
        });

        jButton17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton17MouseClicked(evt);
            }
        });

        jButton18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton18MouseClicked(evt);
            }
        });

        jButton19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton19MouseClicked(evt);
            }
        });

        jButton20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton20MouseClicked(evt);
            }
        });

        jButton22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton22MouseClicked(evt);
            }
        });
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        jButton23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton23MouseClicked(evt);
            }
        });

        jButton24.setToolTipText("");
        jButton24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton24MouseClicked(evt);
            }
        });

        jButton25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton25MouseClicked(evt);
            }
        });

        jButton26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton26MouseClicked(evt);
            }
        });

        jButton27.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton27MouseClicked(evt);
            }
        });

        jButton29.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton29MouseClicked(evt);
            }
        });

        jButton30.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton30MouseClicked(evt);
            }
        });

        jButton31.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton31MouseClicked(evt);
            }
        });

        jButton32.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton32MouseClicked(evt);
            }
        });

        jButton33.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton33MouseClicked(evt);
            }
        });

        jButton34.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton34MouseClicked(evt);
            }
        });

        jLabel2.setText("player 1 turn");

        jButton7.setText("Restart");
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton7MouseClicked(evt);
            }
        });
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(225, 225, 225)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton26, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton33, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton25, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton32, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton30, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton27, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton34, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton15, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton29, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(115, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(75, 75, 75)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton27, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton34, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton26, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton33, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton25, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton32, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton30, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton29, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
       if(groupstatus(1)==1){
          if(turn==1)jButton1.setBackground(Color.red);
          else jButton1.setBackground(Color.yellow);
         switchturn();
       checkwin();
       checkWinRow();
       checkWinDiagonal();
          g1status++;
          r1status++;
          d1status++;
          
      } // TODO add your handling code here:
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        if(groupstatus(1)==2){
          if(turn==1)jButton2.setBackground(Color.red);
          else jButton2.setBackground(Color.yellow);
          switchturn();
         checkwin(); 
         checkWinRow();
         checkWinDiagonal();
        g1status++;
        r2status++;
        d2status++;
        
        
      }   // TODO add your handling code here:
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
   if(groupstatus(1)==3){
          if(turn==1)jButton3.setBackground(Color.red);
          else jButton3.setBackground(Color.yellow);
           switchturn();
           
         checkwin();
         checkWinRow();
         checkWinDiagonal();
        g1status++;
        d3status++;
        r3status++;
         
       
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
  jLabel2.setText("button clicked");
        if(groupstatus(1)==4){
          if(turn==1){ jButton4.setBackground(Color.red);checkwin();
}
          else jButton4.setBackground(Color.yellow);
           switchturn();
           checkwin();
           checkWinRow();
           checkWinDiagonal();
        g1status++;
        d7status++;
        r4status++;
       
       
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4MouseClicked

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
   if(groupstatus(1)==5){
          if(turn==1)jButton5.setBackground(Color.red);
          else jButton5.setBackground(Color.yellow);
          switchturn();
         checkwin();
         checkWinRow();
         checkWinDiagonal();
         
        g1status++;
        d6status++;
        r5status++;
        
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5MouseClicked

    private void jButton6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseClicked
   if(groupstatus(1)==6){
          if(turn==1)jButton6.setBackground(Color.red);
          else jButton6.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinDiagonal();
          checkWinRow();
        g1status++;
        d5status++;
        r6status++;
       
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6MouseClicked

    private void jButton8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseClicked
   if(groupstatus(2)==1){
          if(turn==1)jButton8.setBackground(Color.red);
          else jButton8.setBackground(Color.yellow);
       switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g2status++;
        r1status++;
        d4status++;
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8MouseClicked

    private void jButton9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseClicked
     if(groupstatus(2)==2){
          if(turn==1)jButton9.setBackground(Color.red);
          else jButton9.setBackground(Color.yellow);
        switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g2status++;
         r2status++;
            d1status++;
      }      // TODO add your handling code here:
    }//GEN-LAST:event_jButton9MouseClicked

    private void jButton10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MouseClicked
   if(groupstatus(2)==3){
          if(turn==1)jButton10.setBackground(Color.red);
          else jButton10.setBackground(Color.yellow);
        switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g2status++;
        d2status++;
        d7status++;
        r3status++;
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10MouseClicked

    private void jButton11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton11MouseClicked
   if(groupstatus(2)==4){
          if(turn==1)jButton11.setBackground(Color.red);
          else jButton11.setBackground(Color.yellow);
       switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g2status++;
         d3status++;
         d6status++;
         r4status++;
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11MouseClicked

    private void jButton12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton12MouseClicked
   if(groupstatus(2)==5){
          if(turn==1)jButton12.setBackground(Color.red);
          else jButton12.setBackground(Color.yellow);
       switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g2status++;
        d5status++;
        r5status++;
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12MouseClicked

    private void jButton13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton13MouseClicked
   if(groupstatus(2)==6){
          if(turn==1)jButton13.setBackground(Color.red);
          else jButton13.setBackground(Color.yellow);
       switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
          
        g2status++;
        d8status++;
        r6status++;
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13MouseClicked

    private void jButton15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton15MouseClicked
   if(groupstatus(3)==1){
          if(turn==1)jButton15.setBackground(Color.red);
          else jButton15.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          
        g3status++;
        r1status++;
        
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15MouseClicked

    private void jButton16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton16MouseClicked
   if(groupstatus(3)==2){
          if(turn==1)jButton16.setBackground(Color.red);
          else jButton16.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
          
        g3status++;
         r2status++;
          d4status++;
          d7status++;
        
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton16MouseClicked

    private void jButton17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton17MouseClicked
   if(groupstatus(3)==3){
          if(turn==1)jButton17.setBackground(Color.red);
          else jButton17.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g3status++;
            d1status++;
            d6status++;
            r3status++;
      
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton17MouseClicked

    private void jButton18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton18MouseClicked
   if(groupstatus(3)==4){
          if(turn==1)jButton18.setBackground(Color.red);
          else jButton18.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g3status++;
        d2status++;
        d5status++;
        r4status++;
       
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton18MouseClicked

    private void jButton19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton19MouseClicked
   if(groupstatus(3)==5){
          if(turn==1)jButton19.setBackground(Color.red);
          else jButton19.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g3status++;
         d3status++;
         d8status++;
         r5status++;
        
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton19MouseClicked

    private void jButton20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MouseClicked
   if(groupstatus(3)==6){
          if(turn==1)jButton20.setBackground(Color.red);
          else jButton20.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
        g3status++;
        r6status++;
        
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton20MouseClicked

    private void jButton22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton22MouseClicked
   if(groupstatus(4)==1){
          if(turn==1)jButton22.setBackground(Color.red);
          else jButton22.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g4status++;
        r1status++;
        d7status++;
        
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton22MouseClicked

    private void jButton23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton23MouseClicked
   if(groupstatus(4)==2){
          if(turn==1)jButton23.setBackground(Color.red);
          else jButton23.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g4status++;
         r2status++;
         d6status++;
        
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton23MouseClicked

    private void jButton24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton24MouseClicked
   if(groupstatus(4)==3){
          if(turn==1)jButton24.setBackground(Color.red);
          else jButton24.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g4status++;
         d4status++;
         d5status++;
         r3status++;
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton24MouseClicked

    private void jButton25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton25MouseClicked
   if(groupstatus(4)==4){
          if(turn==1)jButton25.setBackground(Color.red);
          else jButton25.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g4status++;
            d1status++;
            d8status++;
            r4status++;
        
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton25MouseClicked

    private void jButton26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton26MouseClicked
   if(groupstatus(4)==5){
          if(turn==1)jButton26.setBackground(Color.red);
          else jButton26.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g4status++;
        d2status++;
        r5status++;
       
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton26MouseClicked

    private void jButton27MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton27MouseClicked
   if(groupstatus(4)==6){
          if(turn==1)jButton27.setBackground(Color.red);
          else jButton27.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
           g4status++;
            d3status++;
        r6status++;
   }
    }//GEN-LAST:event_jButton27MouseClicked

    private void jButton29MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton29MouseClicked
if(groupstatus(5)==1){
          if(turn==1)jButton29.setBackground(Color.red);
          else jButton29.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g5status++;
        r1status++;
        d6status++;
       
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton29MouseClicked

    private void jButton30MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton30MouseClicked
if(groupstatus(5)==2){
          if(turn==1)jButton30.setBackground(Color.red);
          else jButton30.setBackground(Color.yellow);
           switchturn();
          checkwin();
           checkWinRow();
           checkWinDiagonal();
        g5status++;
         r2status++;
         d5status++;
      }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton30MouseClicked

    private void jButton31MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton31MouseClicked
if(groupstatus(5)==3){
          if(turn==1)jButton31.setBackground(Color.red);
          else jButton31.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g5status++;
        d8status++;
        r3status++;
        
      }         // TODO add your handling code here:
    }//GEN-LAST:event_jButton31MouseClicked

    private void jButton32MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton32MouseClicked
if(groupstatus(5)==4){
          if(turn==1)jButton32.setBackground(Color.red);
          else jButton32.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
        g5status++;
        r4status++;
        
      }         // TODO add your handling code here:
    }//GEN-LAST:event_jButton32MouseClicked

    private void jButton33MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton33MouseClicked
if(groupstatus(5)==5){
          if(turn==1)jButton33.setBackground(Color.red);
          else jButton33.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g5status++;
            d1status++;
             d4status++;
             r5status++;
        
      }         // TODO add your handling code here:
    }//GEN-LAST:event_jButton33MouseClicked

    private void jButton34MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton34MouseClicked
if(groupstatus(5)==6){
          if(turn==1)jButton34.setBackground(Color.red);
          else jButton34.setBackground(Color.yellow);
           switchturn();
          checkwin();
          checkWinRow();
          checkWinDiagonal();
        g5status++;
        d2status++;
        r6status++;
        
      }         // TODO add your handling code here:
    }//GEN-LAST:event_jButton34MouseClicked
     
    public void restart(){
        g1status=1;
        g2status=1;
        g3status=1;
        g4status=1;
        g5status=1;
        r1status=1;
        r2status=1;
        r3status=1;
        r4status=1;
        r5status=1;
        r6status=1;
        d1status = 1;
        d2status = 1;
         d3status =1;
         d4status = 1;
         d5status = 1;
    d6status = 1;
    d7status = 1;
    d8status = 1;
    
    jButton1.setBackground(null);
     jButton2.setBackground(null);
      jButton3.setBackground(null); 
      jButton4.setBackground(null);
       jButton5.setBackground(null);
        jButton6.setBackground(null);
         jButton8.setBackground(null);
          jButton9.setBackground(null);
           jButton10.setBackground(null);
            jButton11.setBackground(null); 
            jButton12.setBackground(null);
             jButton10.setBackground(null);
            jButton11.setBackground(null); 
            jButton12.setBackground(null); 
            jButton13.setBackground(null);
            jButton15.setBackground(null); 
            jButton16.setBackground(null);
             jButton17.setBackground(null);
            jButton18.setBackground(null); 
            jButton19.setBackground(null);
            jButton20.setBackground(null);
            jButton22.setBackground(null); 
            jButton23.setBackground(null); 
            jButton24.setBackground(null);
            jButton25.setBackground(null); 
            jButton26.setBackground(null);
             jButton27.setBackground(null);
            jButton29.setBackground(null); 
            jButton30.setBackground(null);
             jButton31.setBackground(null);
            jButton32.setBackground(null); 
            jButton33.setBackground(null);
            jButton34.setBackground(null);
            
            jButton1.setEnabled(true);
             jButton2.setEnabled(true);
              jButton3.setEnabled(true);
               jButton4.setEnabled(true);
                jButton5.setEnabled(true);
                 jButton6.setEnabled(true);
                  jButton8.setEnabled(true);
                   jButton9.setEnabled(true);
                    jButton10.setEnabled(true);
                     jButton11.setEnabled(true);
                      jButton12.setEnabled(true);
                       jButton13.setEnabled(true);
                        jButton15.setEnabled(true);
                         jButton16.setEnabled(true);
                          jButton17.setEnabled(true);
                           jButton18.setEnabled(true);
                            jButton19.setEnabled(true);
                             jButton20.setEnabled(true);
                              jButton22.setEnabled(true);
                               jButton23.setEnabled(true);
                                jButton24.setEnabled(true);
                                 jButton25.setEnabled(true);
                                  jButton26.setEnabled(true);
                                   jButton27.setEnabled(true);
                                    jButton29.setEnabled(true);
                                     jButton30.setEnabled(true);
                                      jButton31.setEnabled(true);
                                       jButton32.setEnabled(true);
                                        jButton33.setEnabled(true);
                                         jButton34.setEnabled(true);
                                            turn=1;
                                            jLabel2.setText("Player 1 turn");
                                         
                               
                                  
            
            
      
      
    
    
    

        
        
        
        
                        
        
    }
    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
             // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseClicked
           restart();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Connect4Game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Connect4Game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Connect4Game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Connect4Game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Connect4Game().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

}